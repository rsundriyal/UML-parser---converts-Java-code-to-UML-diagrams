 

public interface A1 {
	void hello();
}
 
