
public interface maths {
	
	int sub(int x, int y);
	
	Double multiply(Double x, Double y);
	
	
}
