import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

public class StringTest {
	

  	static final String onetoMany = new String("\"1\"--\"*\"" );
	static final String zerotomany= new String("\"0\"--\"*\"");
	
	static final String zerotoone= new String("\"0\"--\"1\"");
	static 	final String onetoone= new String("\"1\"--\"1\"");
	
	static final String word_zerotomany= new String("\"0\"--\"many\"");
	
	public static List<String> collection_arr_association = new CopyOnWriteArrayList<String>();
	public static List<String> association = new CopyOnWriteArrayList <String>();	
	//public static List<String> association_to_be_removed = new ArrayList <String>();
	
	public static void main(String[] args) {
		
		StringBuilder sbr = new StringBuilder();

		// Class01 "1" *-- "many" Class02 : contains
		String c1="class1";
		String c2="class2";
		
		sbr.append(c1);
	//sbr.append(" ");
		sbr.append(zerotoone);
	//sbr.append(" ");
		sbr.append(c2);
		
		String  asscn= sbr.toString();

		System.out.println(asscn);
		
		
		String[] splitted= asscn.split(word_zerotomany);
		
	System.out.println(splitted.length);
	System.out.println(Arrays.asList(splitted));
	System.out.println(asscn.matches(word_zerotomany));
	
	asscn=asscn.replace(word_zerotomany, zerotomany);
	
	System.out.println(asscn);
	
	StringBuilder sbr2 = new StringBuilder();
	
	sbr2.append(c2);
	//sbr2.append(" ");
	sbr2.append(zerotoone);
	//sbr2.append(" ");
	sbr2.append(c1);
		
		String  asscn2= sbr2.toString();
		
		
		System.out.println(asscn2);
		association.add(asscn);
		association.add(asscn2);
		association.add("class3\"0\"--\"1\"class1");
		System.out.println(association);
		
		String[] splitstring=null;
		
		for(Iterator<String> it = association.iterator(); it.hasNext(); ){
			
			String s=it.next();
			System.out.println("loop string"+ s);
			StringBuilder chkr= new StringBuilder();
			splitstring= s.split(zerotoone);
			System.out.println(Arrays.asList(splitstring));
			chkr.append(splitstring[1]);
			chkr.append(zerotoone);
			chkr.append(splitstring[0]);
			
			System.out.println("chkr.toString()"+ chkr.toString());
			if (association.contains(chkr.toString())){
				association.remove(chkr.toString());
				association.remove(s);
				
				StringBuilder new1to1entry= new StringBuilder();
				new1to1entry.append(splitstring[1]);
				new1to1entry.append(onetoone); 
				new1to1entry.append(splitstring[0]);
				association.add(new1to1entry.toString());
			}
		}
		System.out.println("interim_association"+association);
		
		
		collection_arr_association.add("class1\"0\"--\"many\"class3");
		collection_arr_association.add("class3\"0\"--\"many\"class4");
		String scoll=null;
			for(Iterator<String> it = collection_arr_association.iterator(); it.hasNext(); ){
			
			scoll=it.next();
			System.out.println("loop string"+ scoll);
			StringBuilder chkr= new StringBuilder();
			splitstring= scoll.split(word_zerotomany);
			System.out.println("splitstring"+Arrays.asList(splitstring));
			chkr.append(splitstring[1]);
			chkr.append(zerotoone);
			chkr.append(splitstring[0]);
			System.out.println("chkr"+chkr);
			String chkrString=chkr.toString();
			if(association.contains(chkrString)){
				
				//association_to_be_removed.add(chkrString);
				association.remove(chkrString);
				//removes current 0 to many item
				collection_arr_association.remove(scoll);
				//association_to_be_removed.add(chkrString);
				StringBuilder newentry_bldr= new StringBuilder();
				newentry_bldr.append(splitstring[0]);
				newentry_bldr.append(onetoMany);
				newentry_bldr.append(splitstring[1]);
				System.out.println("newentry_bldr.toString()"+newentry_bldr.toString());
				collection_arr_association.add(newentry_bldr.toString());
				
			}
			
		}
	
			System.out.println("final_association"+ association);
			System.out.println("interim_collection_arr_association"+ collection_arr_association);
		
			
			for(int i=0;i<collection_arr_association.size();i++ ){
				
				collection_arr_association.set(i,collection_arr_association.get(i).replace(word_zerotomany, zerotomany));
			}
			
			System.out.println("final_collection_arr_association");
			
			System.out.println(collection_arr_association);
			/*String ibvie="[intx, int y]";
		
		String newstr=ibvie.replace('[', '(');
		
		System.out.println("ibvie"+ ibvie);
		System.out.println("newstr"+newstr);
		
		String str1 = "A1";
	      String str2 = "A1";
	      String str3 = "B1";

	      int result = str1.compareToIgnoreCase( str2 );
	   //   System.out.println(result);
		  
	      result = str2.compareToIgnoreCase( str3 );
	     // System.out.println(result);
		 
	      result = str3.compareToIgnoreCase( str1 );
	      //System.out.println(result);
		
		
		
	      
	      
	      Set<String> s = new 
	      
		ByteArrayOutputStream bous = new ByteArrayOutputStream();
		
		String source = "@startuml\n";
		source +="class Apartment{\n";
		source +="rooms: int[]\n";
		source +="}\n";
		source +="class House\n";
		source +="Apartment <|-- House\n";
		source +="class Commune\n";
		source += "@enduml\n";
		
		SourceStringReader reader = new SourceStringReader(source);				
	    // Write the first image to "png"
	    String desc="";
		try{
			desc = reader.generateImage(bous);
		
	    // Return a null string if no generation
	    byte [] data = bous.toByteArray();

	    InputStream in = new ByteArrayInputStream(data);
	    BufferedImage convImg = ImageIO.read(in);
	    
	    
	    
	    
	   
//			ImageIO.write(convImg, "png", new File("C:\\Users\\BG\\Desktop\\UMLTEST.png"));
} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    System.out.print(desc);	
*/		
	}
}
