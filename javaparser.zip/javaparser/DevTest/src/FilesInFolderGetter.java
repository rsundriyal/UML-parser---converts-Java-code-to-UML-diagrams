import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class FilesInFolderGetter {

	public static void main(String[] args) {
		List<String> parsedList = new ArrayList<String>();
		final String JAVA_CONSTANT = "java";

		try {
			Files.walk(Paths.get("D:/SJSU/Paul_202/uml-parser-test-2/uml-parser-test-2")).forEach(filePath -> {
				if (Files.isRegularFile(filePath)) {
					System.out.println(filePath);
					File f1 = filePath.toFile();
					System.out.println(f1.getName());
					String[] splitted = f1.getName().split("\\.");
					System.out.println();
					
					if (splitted[1].equals(JAVA_CONSTANT)) {
						parsedList.add(splitted[0]);
					}
				}
			});
			System.out.println(parsedList);
			System.out.println(parsedList.contains("Ax"));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
