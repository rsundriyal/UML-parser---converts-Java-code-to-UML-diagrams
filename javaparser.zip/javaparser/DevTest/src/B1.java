
public class B1 extends P implements A1 {

	private int abc = 0;
	public int xyz = 5;

	public B1() {
		abc = 5;
	}

	public int add(int x, int y) {
		return 5;
	}

	public int sub(int x, int y) {
		return 1;
	}

	@Override
	public void hello() {
		// TODO Auto-generated method stub
		return;
	}

}
