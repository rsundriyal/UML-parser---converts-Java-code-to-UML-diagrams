 

public class C2 implements A2 {
    
    public void test( A2 a2, A1 a1 ) {
        // call a2 methods
    }
    
}
 
