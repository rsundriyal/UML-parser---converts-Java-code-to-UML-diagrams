import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.soap.Addressing;
//implements maths
public class CollectionFunc {
	
	private int x=0; 
	public int y=0; 
	public C2 c2attr = new C2();
	public List<C1> addC1 = new ArrayList<C1>();
	C1[] c1arr= new C1[10];
	
	CollectionFunc(){
		x=1;
	}
	
	public static void main(String[] args) {
		
		CollectionFunc cf= new CollectionFunc();
		List<Integer> add = new ArrayList<Integer>();
		List<C2> addC2 = new ArrayList<C2>();
		List<C1> addC1 = new ArrayList<C1>();
		
		
	}
	public List<Double>  addinteger(List<Double> add ,C1 c1 ){
		return add;
	}

	public int sub(int x, int y) {
		// TODO Auto-generated method stub
		int d=5;
		int z= x+y+d;
		return z;
	}
/*
	@Override
	public Double multiply(Double x, Double y) {
		// TODO Auto-generated method stub
		return null;
	}*/
}
