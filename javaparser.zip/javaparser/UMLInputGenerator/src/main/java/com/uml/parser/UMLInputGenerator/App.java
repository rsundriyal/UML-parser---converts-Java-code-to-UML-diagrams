package com.uml.parser.UMLInputGenerator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Ref;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseException;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.ReferenceType;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

/**
 * Hello world!
 *
 */
public class App {

	List<String> classesParsed = new ArrayList<String>();
	List<String> interfaceParsed = new ArrayList<String>();
	static List<String> usedClasses_interfaces = new ArrayList<String>();
	static List<String> mtdDecln = new ArrayList<String>();
	static List<String> mtdDecnNEW= new ArrayList<String>();
	public static Set<String> interface_classesUsed_Mtds = new HashSet<String>();
	public static Set<String> collection_arr_association = new HashSet<String>();
	static Set<String> association= new HashSet<String>();

	private void populateParsedFiles() {
		List<String> parsedList = new ArrayList<String>();
		final String JAVA_CONSTANT = "java";

		// FileInputStream in = null;
		// CompilationUnit cu = null;

		try {
			Files.walk(Paths.get("D:/SJSU/Paul_202/JavaParser/DevTest/src/CollectionFunc.java")).forEach(filePath -> {
				if (Files.isRegularFile(filePath)) {
					System.out.println(filePath);
					File f1 = filePath.toFile();
					System.out.println(f1.getName());
					String[] splitted = f1.getName().split("\\.");
					System.out.println();

					if (splitted[1].equals(JAVA_CONSTANT)) {
						try {
							FileInputStream in = new FileInputStream(filePath.toString());
							CompilationUnit cu = JavaParser.parse(in);

							Object node = cu.getData();

							// System.out.println(node.);
							// Node pr = cu.getParentNode();
							// parentnode.
							// System.out.println("CU B1 types"+cu.getTypes());

							// Type Declaration can be AnnotationDeclaration,
							// ClassOrInterfaceDeclaration,
							// EmptyTypeDeclaration, EnumDeclaration
							// VVVVVVIMP ClassOrInterfaceDeclaration has private
							// boolean interface_;
							ClassOrInterfaceDeclaration cx = (ClassOrInterfaceDeclaration) cu.getTypes().get(0);
							if (cx.isInterface()) {
								interfaceParsed.add(splitted[0]);
							} else
								classesParsed.add(splitted[0]);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						// parsedList.add(splitted[0]);
					}
				}
			});
			// System.out.println(classesParsed );
			// System.out.println(interfaceParsed);
			// System.out.println(parsedList.contains("Ax"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// System.out.println( "Hello World!" );

		FileInputStream in = null;
		CompilationUnit cu = null;
		// App app= new App();
		// app.populateParsedFiles();

		try {
			in = new FileInputStream("D:/SJSU/Paul_202/JavaParser/DevTest/src/CollectionFunc.java");
			cu = JavaParser.parse(in);
			Object node = cu.getData();

			// System.out.println(node.);
			// Node pr = cu.getParentNode();
			// parentnode.
			// System.out.println("CU B1 types"+cu.getTypes());

			// Type Declaration can be AnnotationDeclaration,
			// ClassOrInterfaceDeclaration, EmptyTypeDeclaration,
			// EnumDeclaration
			// VVVVVVIMP ClassOrInterfaceDeclaration has private boolean
			// interface_;
			ClassOrInterfaceDeclaration cx = (ClassOrInterfaceDeclaration) cu.getTypes().get(0);
			// MethodDeclaration mx= (MethodDeclaration) cx.get;
			System.out.println(cx.getExtends());
			// System.out.println(cx.getExtends().get(0));
			System.out.println(cx.getImplements());
			// System.out.println(cx.getImplements().get(0));
			System.out.println("Parent node form child:" + cx.getParentNode());

			System.out.println("Cu children nodes");
			System.out.println(cu.getChildrenNodes());
			System.out.println("cu.getclass" + cu.getChildrenNodes().get(0).getClass());
			// System.out.println("cu.getclass"+cu.getChildrenNodes().get(1).getClass());
			// System.out.println("cu.getclass"+cu.getChildrenNodes().get(2).getClass());
			// System.out.println("cu.getclass"+cu.getChildrenNodes().get(3).getClass());
			System.out.println("Size" + cu.getChildrenNodes().size());
			System.out.println("cu.children " + cu.getChildrenNodes().get(0).getChildrenNodes());

			System.out.println("cx.getChildernNodes" + cx.getChildrenNodes());
			System.out.println("Size" + cx.getChildrenNodes().size());
			System.out.println("cx.getclass" + cx.getChildrenNodes().get(0).getClass());
			System.out.println("cx.getclass" + cx.getChildrenNodes().get(1).getClass());
			System.out.println("cx.getclass" + cx.getChildrenNodes().get(2).getClass());
			System.out.println("cx.getclass" + cx.getChildrenNodes().get(3).getClass());
			System.out.println("cx.getclass" + cx.getChildrenNodes().get(4).getClass());
			// ClassOrInterfaceType clt=(ClassOrInterfaceType)
			// cx.getChildrenNodes().get(0);
			// System.out.println("cx.getclass"+cx.getChildrenNodes().get(5).getClass());
			// System.out.println("cx.getclass"+cx.getChildrenNodes().get(6).getClass());
			Node parentnode = cu.getParentNode();
			System.out.println("Cu parent  nodes");
			// System.out.println(parentnode);

		} catch (FileNotFoundException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// Below is to retrieve mtds and attributes

		// prints the resulting compilation unit to default system output

		// System.out.println("below is cu.toString()");
		// System.out.println(cu.toString());

		System.out.println("==============BELOW IS VISITING METHODS==========");
		new MethodVisitor().visit(cu, null);
		System.out.println("Trying to get Types");
		// List<TypeDeclaration> lst =cu.getTypes();
		// System.out.println(lst.size());
		// System.out.println(lst.get(0).getName());
		// processNode(cu.get);
		cu.getChildrenNodes();
		List<VariableDeclarator> lstvars = new FieldDeclaration().getVariables();
		System.out.println(lstvars);

		 new FieldVisitor().visit(cu, null);

		System.out.println("*********usedClasses_interfaces" + usedClasses_interfaces);
		System.out.println("##########################" + mtdDecln);
		System.out.println("######interface_classesUsed_Mtds_bothParams_n_body" + interface_classesUsed_Mtds);
		System.out.println("mtdDecnNEW"+mtdDecnNEW);
	}

	/**
	 * Simple visitor implementation for visiting MethodDeclaration nodes.
	 */
	public static class MethodVisitor extends VoidVisitorAdapter {

		@Override
		public void visit(MethodDeclaration n, Object arg) {
			// here you can access the attributes of the method.
			// this method will be called for all methods in this
			// CompilationUnit, including inner class methods

			System.out.println("Entering MethodVisitor VISIT");
			System.out.println("(n.getName(): " + n.getName());
			System.out.println("n.getTypeParameters(): " + n.getTypeParameters());
			System.out.println("n.getModifiers()"+ n.getModifiers());
			System.out.println("n.getNameExpr().getChildrenNodes()"+n.getNameExpr().getChildrenNodes());
			System.out.println("n.getNameExpr()"+n.getNameExpr());
			String str = n.getDeclarationAsString(true, false);
			System.out.println("n.getDeclarationAsString(true, false): " + str);
			
			System.out.println("UMMEED"+ n.getType());
			
			int space = str.indexOf(" ");
			String before = str.substring(0, space);
			String after = str.substring(space + 1);
			if (before.equals("public")) {
				System.out.println("+ " + after);
				mtdDecln.add("+ " + after);
			}
			// below is for dependency in mtd declrn

			List<Parameter> plist = n.getParameters();
			System.out.println("plist" + plist);
			StringBuilder sbr=new StringBuilder();
			
			boolean moreParams=false;
			
			for (Parameter p : plist) {
				
				if (moreParams ){
				sbr.append(",");				
				}
				moreParams=true;
			
				System.out.println("pgetType___" + p.getType());
				System.out.println("p.getType()Class" + p.getType().getClass());
				System.out.println("p_getId_getName__"+p.getId().getName());
				
				
				sbr.append(p.getId().getName());
				sbr.append(":");
				sbr.append( p.getType());
				
				
				// for array p.getType().getChildrenNodes().get(0) will yiled
				// the refdatatype while for collection we need to dig futher
				if (p.getType() instanceof ReferenceType) {
					System.out.println("p.getType().getChildrenNodes()" + p.getType().getChildrenNodes());
					System.out.println("p.getType().getChildrenNodes().get(0)" + p.getType().getChildrenNodes().get(0));
					if (p.getType().getChildrenNodes().get(0).getChildrenNodes().size() == 0)
						interface_classesUsed_Mtds.add(p.getType().getChildrenNodes().get(0).toString());
					else {
						System.out.println("p.getType().getChildrenNodes().get(0).getChildrenNodes().get(0).toString()"
								+ p.getType().getChildrenNodes().get(0).getChildrenNodes().get(0).toString());
						interface_classesUsed_Mtds
								.add(p.getType().getChildrenNodes().get(0).getChildrenNodes().get(0).toString());
					}

				}
				if (p.getType() instanceof ClassOrInterfaceType) {

					System.out.println("p.getType().getChildrenNodes().get(0)" + p.getType().getChildrenNodes().get(0));
					interface_classesUsed_Mtds.add(p.getType().getChildrenNodes().get(0).toString());
				}
				System.out.println("sbr.toString()"+sbr.toString());
			}
			
			StringBuilder sbrmtd= new StringBuilder();
			
			if(n.getModifiers()==1||n.getModifiers()==9){
			sbrmtd.append("+ ");
			System.out.println("getName______"+n.getName());
			sbrmtd.append(n.getName());
			sbrmtd.append("(");
			sbrmtd.append(sbr);
			sbrmtd.append(")");
			sbrmtd.append(" : ");
			sbrmtd.append(n.getType());
			mtdDecnNEW.add(sbrmtd.toString());
			}

			
			// The below is for dependency in mtds stmts
			BlockStmt blockStmt = n.getBody();

			System.out.println("blockStmt" + blockStmt);

			for (Node nblock : blockStmt.getChildrenNodes()) {
				System.out.println("nblock" + nblock.getClass());
				if (nblock instanceof ExpressionStmt) {
					ExpressionStmt exprStmt = (ExpressionStmt) nblock;
					List<Node> nodeExpr = exprStmt.getChildrenNodes();
					if (nodeExpr.size() > 0) {
						VariableDeclarationExpr vd = (VariableDeclarationExpr) nodeExpr.get(0);
						System.out.println("nblock_vdgetType" + vd.getType());
						if (vd.getType().getChildrenNodes().size() > 0) {
							System.out.println("vdgetTypeChilds__" + vd.getType().getChildrenNodes().get(0).getClass());
							ClassOrInterfaceType cit = (ClassOrInterfaceType) vd.getType().getChildrenNodes().get(0);
							System.out.println("cit" + cit.getTypeArgs());
							
							interface_classesUsed_Mtds.add(cit.getTypeArgs()!=null?cit.getTypeArgs().get(0).toString():cit.toString());
						}
					}

				}
			}
		/*	System.out.println("getClass" + blockStmt.getChildrenNodes().get(0).getClass());
			System.out.println("blockStmt.getChildrenNodes()" + blockStmt.getChildrenNodes());
			System.out.println("blockStmt.getChildrenNodes().size()" + blockStmt.getChildrenNodes().size());
			if (blockStmt.getChildrenNodes().size() == 3) {
				System.out.println("blockStmtgetClass 0" + blockStmt.getChildrenNodes().get(0).getClass());
				System.out.println("blockStmtgetClass 1" + blockStmt.getChildrenNodes().get(1).getClass());
				System.out.println("blockStmtgetClass 2" + blockStmt.getChildrenNodes().get(2).getClass());
			}
			
			if (blockStmt.getChildrenNodes().size() > 0
					&& blockStmt.getChildrenNodes().get(0) instanceof ExpressionStmt) {
				ExpressionStmt exprStmt = (ExpressionStmt) blockStmt.getChildrenNodes().get(0);
				System.out.println(exprStmt.getChildrenNodes());
				System.out.println("exprStmt GetClass" + exprStmt.getChildrenNodes().get(0).getClass());
				System.out.println("exprStmt0" + exprStmt.getChildrenNodes().get(0));
				VariableDeclarationExpr vd = (VariableDeclarationExpr) exprStmt.getChildrenNodes().get(0);
				System.out.println("vdgetType__" + vd.getType());
				if (vd.getType().getChildrenNodes().size() > 0) {
					System.out.println("vdgetTypeChilds__" + vd.getType().getChildrenNodes().get(0).getClass());
					ClassOrInterfaceType cit = (ClassOrInterfaceType) vd.getType().getChildrenNodes().get(0);
					System.out.println("cit" + cit.getTypeArgs());
					
					usedClasses_interfaces.add(cit.getTypeArgs()!=null?cit.getTypeArgs().get(0).toString():cit.toString());
				}
			}	
			
			if (blockStmt.getChildrenNodes().size() > 1
					&& blockStmt.getChildrenNodes().get(1) instanceof ExpressionStmt) {
				ExpressionStmt exprStmt = (ExpressionStmt) blockStmt.getChildrenNodes().get(1);
				System.out.println(exprStmt.getChildrenNodes());
				System.out.println("exprStmt GetClass" + exprStmt.getChildrenNodes().get(0).getClass());
				System.out.println("exprStmt0" + exprStmt.getChildrenNodes().get(0));
				VariableDeclarationExpr vd = (VariableDeclarationExpr) exprStmt.getChildrenNodes().get(0);
				System.out.println("vdgetType" + vd.getType());
				if (vd.getType().getChildrenNodes().size() > 0) {
					System.out.println("vdgetTypeChilds" + vd.getType().getChildrenNodes().get(0).getClass());
					ClassOrInterfaceType cit = (ClassOrInterfaceType) vd.getType().getChildrenNodes().get(0);
					System.out.println("cit" + cit.getTypeArgs());
					usedClasses_interfaces.add(cit.getTypeArgs().get(0).toString());
					System.out.println();
					
					 * System.out.println("vdgetTypeChilds"+vd.getType().
					 * getChildrenNodes().get(1).getClass());
					 * ClassOrInterfaceType
					 * cit1=(ClassOrInterfaceType)vd.getType().getChildrenNodes(
					 * ).get(1); System.out.println("cit2"+cit.getTypeArgs());
					 

					System.out.println("Size_exprStmt " + exprStmt.getChildrenNodes().size());
					if (exprStmt.getChildrenNodes().size() == 3) {
						System.out.println("exprStmt 1" + exprStmt.getChildrenNodes().get(1).getClass());
						System.out.println("exprStmt 2" + exprStmt.getChildrenNodes().get(2).getClass());
					}
				}
			}
			if (blockStmt.getChildrenNodes().size() > 2
					&& blockStmt.getChildrenNodes().get(2) instanceof ExpressionStmt) {
				ExpressionStmt exprStmt = (ExpressionStmt) blockStmt.getChildrenNodes().get(2);
				System.out.println(exprStmt.getChildrenNodes());
				System.out.println("exprStmt GetClass" + exprStmt.getChildrenNodes().get(0).getClass());
				System.out.println("exprStmt0" + exprStmt.getChildrenNodes().get(0));
				VariableDeclarationExpr vd = (VariableDeclarationExpr) exprStmt.getChildrenNodes().get(0);
				System.out.println("vdgetType" + vd.getType());
				if (vd.getType().getChildrenNodes().size() > 0) {
					System.out.println("vdgetTypeChilds" + vd.getType().getChildrenNodes().get(0).getClass());
					ClassOrInterfaceType cit = (ClassOrInterfaceType) vd.getType().getChildrenNodes().get(0);
					System.out.println("cit" + cit.getTypeArgs());
					usedClasses_interfaces.add(cit.getTypeArgs().get(0).toString());

					System.out.println("Size_exprStmt " + exprStmt.getChildrenNodes().size());
					if (exprStmt.getChildrenNodes().size() == 3) {
						System.out.println("exprStmt 1" + exprStmt.getChildrenNodes().get(1).getClass());
						System.out.println("exprStmt 2" + exprStmt.getChildrenNodes().get(2).getClass());
					}
				}
			}*/

			System.out.println("(n.getParameters()).get(0).getType(): " + (n.getParameters()).get(0).getType());

			System.out.println("n.getModifiers(): " + n.getModifiers());
		}

	}

	private static class FieldVisitor extends VoidVisitorAdapter {

		@Override
		public void visit(FieldDeclaration n, Object arg) {
			// here you can access the attributes of the method.
			// this method will be called for all methods in this
			// CompilationUnit, including inner class methods
			VariableDeclarator vd = (VariableDeclarator) (n.getVariables()).get(0);
			System.out.println("vd.getId(): " + vd.getId());
			System.out.println("n.getType(): " + n.getType());
			String str=n.getType().toString();
			List<Node> node=n.getChildrenNodes();
			StringBuilder sbr=new StringBuilder();
			if (str.contains("[") )
			{
				System.out.println("[__"+node.get(0).getChildrenNodes().get(0).toString());
				
			}
			if (str.contains("<"))
			{
				String classassocnmul = node.get(0).getChildrenNodes().get(0).getChildrenNodes().get(0).toString();
				System.out.println("[2__"+classassocnmul);
				
			}
			
			
			System.out.println("n.getVariables(): " + n.getVariables());
			System.out.println("n.getModifiers(): " + n.getModifiers());
			System.out.println("getClass_"+n.getClass());
			System.out.println("getType_getClass" + n.getType().getClass());
			if( n.getType() instanceof ReferenceType ){
				// assocation may be der
				
				System.out.println("node"+ node);
				System.out.println("node.get(0).getClass()"+node.get(0).getClass());
				System.out.println("node.get(1).getClass()"+node.get(1).getClass());
				ReferenceType rfinside=  (ReferenceType)node.get(0);
				
				System.out.println("rfinside: "+rfinside);
				List<Node>nodes =rfinside.getChildrenNodes();
				System.out.println("rfinsidenodes: "+ nodes);
				if(nodes.size()>0 ){
					//means der is an asociation for sure
					System.out.println("Enterednodesize>0");
					System.out.println(nodes.get(0).getClass());
					
					ClassOrInterfaceType cit=(ClassOrInterfaceType)nodes.get(0);

					if(cit.getChildrenNodes().size()!=0){
						System.out.println("IIndLevel");

						System.out.println(cit.getChildrenNodes().get(0).getClass());
					//System.out.println(cit.getChildrenNodes().get(1).getClass());
					}
				}
				if(nodes.size()>1 ){
					System.out.println(nodes.get(1).getClass());
				}
				
				//rfinside.getChildrenNodes().get(0).;
				
				/*if (rfinside.getType().getChildrenNodes().size() > 0) {
					System.out.println("vdgetTypeChilds__" + vd.getType().getChildrenNodes().get(0).getClass());
					ClassOrInterfaceType cit = (ClassOrInterfaceType) vd.getType().getChildrenNodes().get(0);
					System.out.println("cit" + cit.getTypeArgs());
					
					interface_classesUsed_Mtds.add(cit.getTypeArgs()!=null?cit.getTypeArgs().get(0).toString():cit.toString());
				}
*/				
			}
			System.out.println("exiting field visitor");

		}
	}

	// Logic..Populate the list with the classes which r to be parsed
	// call all the methods to be parsed i n for loop 1 by 1 for each do below
	// attributes 4 lists interface impltd,used n classes impltd n used , 1 list
	// for mtd decln, 1 list of params, 1 list of uses
	// Step 1 determine its class/interface and make an entry in golbal list
	// Step 2 get the classes extnd n interfaces impltd
	// Get child A>if mtd declrn 1.populate signature 2. chk uses using
	// prepopulated list of file parsed
	// B> if field declrn 1. populate List of this class 2. Put association list
	// any references

	// Note only the consumers of mtd will have dependency/ will populate the
	// list , the declarator/creator of function will not populate dependency
	// list
	//
}
