package com.uml.parser.UMLInputGenerator;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.imageio.ImageIO;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseException;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.PrimitiveType;
import com.github.javaparser.ast.type.ReferenceType;

import net.sourceforge.plantuml.SourceStringReader;

/**
 * Hello world!
 *
 */
public class AppDev2_wo_visitor {

	static List<String> classesParsed = new ArrayList<String>();
	static List<String> interfaceParsed = new ArrayList<String>();
	static List<String> classes_interfaceParsed = new ArrayList<String>();
	// String ("1" *-- "many");
	static final String onetoMany = new String("\"1\"--\"*\"" );
	static final String zerotomany= new String("\"0\"--\"*\"");
	
	static final String zerotoone= new String("\"0\"--\"1\"");
	static 	final String onetoone= new String("\"1\"--\"1\"");
	
	static final String word_zerotomany= new String("\"0\"--\"many\"");
	
	public static List<String> collection_arr_association = new CopyOnWriteArrayList<String>();
	public static List<String> association = new CopyOnWriteArrayList <String>();	
	
	public static Set<String> finalset_association = new HashSet<String>();
	public static Set<String> finalset_collection_arr_association = new HashSet<String>();
	
	AppDev2_wo_visitor(){
		collection_arr_association = new CopyOnWriteArrayList<String>();
		 association = new CopyOnWriteArrayList <String>();
		 classesParsed = new ArrayList<String>();
		 interfaceParsed = new ArrayList<String>();
		 classes_interfaceParsed = new ArrayList<String>();
	}
	/*
	 * List<FileInfo> listFileInfo = new ArrayList<FileInfo>(); FileInfo
	 * fileInfo = null;
	 * 
	 * public List<FileInfo> getListFileInfo() { return listFileInfo; }
	 * 
	 * public void setListFileInfo(List<FileInfo> listFileInfo) {
	 * this.listFileInfo = listFileInfo; }
	 * 
	 * public FileInfo getFileInfo() { return fileInfo; }
	 * 
	 * public void setFileInfo(FileInfo fileInfo) { this.fileInfo = fileInfo; }
	 */

	private void populateParsedFiles() {
		List<String> parsedList = new ArrayList<String>();
		final String JAVA_CONSTANT = "java";

		// FileInputStream in = null;
		// CompilationUnit cu = null;

		try {
			//D:/SJSU/Paul_202/JavaParser/DevTest/src
			//D:/SJSU/Paul_202/uml-parser-test-5/uml-parser-test-5
			Files.walk(Paths.get("C:/Users/aishwarya/Desktop/parsertestcases/uml-parser-test-3/uml-parser-test-3")).forEach(filePath -> {
				if (Files.isRegularFile(filePath)) {
					System.out.println(filePath);
					File f1 = filePath.toFile();
					System.out.println(f1.getName());
					String[] splitted = f1.getName().split("\\.");
					System.out.println();

					if (splitted[1].equals(JAVA_CONSTANT)) {
						try {
							FileInputStream in = new FileInputStream(filePath.toString());
							CompilationUnit cu = JavaParser.parse(in);

							Object node = cu.getData();

							// System.out.println(node.);
							// Node pr = cu.getParentNode();
							// parentnode.
							System.out.println("CU B1 types" + cu.getTypes());

							// Type Declaration can be AnnotationDeclaration,
							// ClassOrInterfaceDeclaration,
							// EmptyTypeDeclaration, EnumDeclaration
							// VVVVVVIMP ClassOrInterfaceDeclaration has private
							// boolean interface_;
							ClassOrInterfaceDeclaration cx = (ClassOrInterfaceDeclaration) cu.getTypes().get(0);
							if (cx.isInterface()) {
								interfaceParsed.add(splitted[0]);
							} else
								classesParsed.add(splitted[0]);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						// parsedList.add(splitted[0]);
					}
				}
			});
			System.out.println(classesParsed);
			System.out.println(interfaceParsed);
			classes_interfaceParsed = new ArrayList<String>(classesParsed);
			classes_interfaceParsed.addAll(interfaceParsed);
			System.out.println("classes_interfaceParsed"+ classes_interfaceParsed);
			// System.out.println(parsedList.contains("Ax"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// System.out.println( "Hello World!" );

		FileInputStream in = null;
		CompilationUnit cu = null;
		List<ClassOrInterfaceType> extendList = null;
		List<ClassOrInterfaceType> interfaceList = null;

		AppDev2_wo_visitor app = new AppDev2_wo_visitor();
		app.populateParsedFiles();

		FileInfo fileInfotemp = null;
		List<FileInfo> listFileInfo = new ArrayList<FileInfo>();
		ClassOrInterfaceDeclaration cx = null;
		//D:/SJSU/Paul_202/uml-parser-test-5/uml-parser-test-5
		
		final File folder = new File("C:/Users/aishwarya/Desktop/parsertestcases/uml-parser-test-3/uml-parser-test-3");
		final String JAVA_CONSTANT = "java";

		for (final File fileEntry : folder.listFiles()) {
			cx = null;

			String absPath = fileEntry.getAbsolutePath();

			String extn = absPath.substring(absPath.lastIndexOf('.') + 1);
			System.out.println("@@@@@@@@@" + extn);
			if ((!fileEntry.isDirectory()) && (extn.equals(JAVA_CONSTANT))) {
				System.out.println("**********************fileEntry entered*************************");
				String filenamestr = fileEntry.getName();
				System.out.println("Current_File:" + filenamestr);
				String[] filenamearr = filenamestr.split("\\.");
				// System.out.println(filenamearr);
				// System.out.println("Current_FileSplitted:" + filenamearr[0]);

				fileInfotemp = new FileInfo();
				fileInfotemp.filename = filenamearr[0];
				fileInfotemp.filepath = absPath;
				try {
					in = new FileInputStream(fileEntry);
					cu = JavaParser.parse(in);
					Object node = cu.getData();

					for (TypeDeclaration typeDeclaration : cu.getTypes()) {
						if (typeDeclaration instanceof ClassOrInterfaceDeclaration) {
							cx = (ClassOrInterfaceDeclaration) typeDeclaration;
							break;
						}

					}

					if (cx.isInterface()) {
						fileInfotemp.isFIleAnInterface = true;
					}

					extendList = cx.getExtends();

					if (extendList != null) {
						for (ClassOrInterfaceType ciType : extendList) {

							fileInfotemp.classesExtnd.add(ciType.toString());
							fileInfotemp.classesExtnd.retainAll(classesParsed);
						}
					}

					interfaceList = cx.getImplements();
					if (interfaceList != null) {
						for (ClassOrInterfaceType ciType : interfaceList) {

							fileInfotemp.interfaceImpltd.add(ciType.toString());
							fileInfotemp.interfaceImpltd.retainAll(interfaceParsed);
						}
					}
					List<Node> nodes = cx.getChildrenNodes();
					if (nodes != null) {
						for (Node nodeChild : nodes) {
							if (nodeChild instanceof MethodDeclaration) {
								app.populateMtdSignature((MethodDeclaration) nodeChild, fileInfotemp);
							}
							if (nodeChild instanceof FieldDeclaration) {
								app.populateAttributes((FieldDeclaration) nodeChild, fileInfotemp);
							}
							if (nodeChild instanceof ConstructorDeclaration) {
								app.populateConstructors((ConstructorDeclaration) nodeChild, fileInfotemp);
							}
						}
					}
					// to retain only user defd interfaces n classes
					fileInfotemp.interface_classesUsed_Mtds.retainAll(classes_interfaceParsed);
					//association.retainAll(classes_interfaceParsed);
					listFileInfo.add(fileInfotemp);

				} catch (FileNotFoundException | ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			

		}
		
		System.out.println(listFileInfo);
		System.out.println("Before transform_associations:"+association + " " + collection_arr_association);
		
		// create diagram D:\SJSU\Paul_202\JavaParser\DevTest\src
		String path = "C:\\Users\\aishwarya\\Desktop\\abcde.png";
		transform_associations();
		finalset_association=new HashSet<>(association);
		finalset_collection_arr_association= new HashSet<>(collection_arr_association);
		System.out.println("Before transform_associations:"+association + " " + collection_arr_association);
		createDiagram(listFileInfo, path);
		

	}
	
	private  static void transform_associations(){
		String[] splitstring=null;
		
		for(Iterator<String> it = association.iterator(); it.hasNext(); ){
			
			String s=it.next();
			System.out.println("loop_stringassociation"+ s);
			StringBuilder chkr= new StringBuilder();
			splitstring= s.split(zerotoone);
			System.out.println("Arrays_stringassociation"+Arrays.asList(splitstring));
			if(!splitstring[0].equals(s)){
				chkr.append(splitstring[1]);
				chkr.append(zerotoone);
				chkr.append(splitstring[0]);
				
				System.out.println("chkr.toString()"+ chkr.toString());
				if (association.contains(chkr.toString())){
					association.remove(chkr.toString());
					association.remove(s);
					
					StringBuilder new1to1entry= new StringBuilder();
					new1to1entry.append(splitstring[1]);
					new1to1entry.append(onetoone); 
					new1to1entry.append(splitstring[0]);
					association.add(new1to1entry.toString());
				}
			}
		}
		System.out.println("interim_association"+association);
		
		
		String iterator0toMany=null;
		for(Iterator<String> it = collection_arr_association.iterator(); it.hasNext(); ){
		
		iterator0toMany=it.next();
		System.out.println("loopstring_collection"+ iterator0toMany);
		StringBuilder chkr= new StringBuilder();
		splitstring= iterator0toMany.split(word_zerotomany);
		System.out.println("splitstring_collection:"+ Arrays.asList(splitstring));
		System.out.println("iterator0toMany.equals(splitstring)"+ iterator0toMany.equals(splitstring));
		if(!iterator0toMany.equals(splitstring[0]))	
			chkr.append(splitstring[1]);
			chkr.append(zerotoone);
			chkr.append(splitstring[0]);
			System.out.println("chkr"+chkr);
			String chkrString=chkr.toString();
			System.out.println("=====chkrString: " + chkrString+":association: " +association);
			if(association.contains(chkrString)){
				
				//association_to_be_removed.add(chkrString);
				association.remove(chkrString);
				//removes current 0 to many item
				collection_arr_association.remove(iterator0toMany);
				//association_to_be_removed.add(chkrString);
				StringBuilder newentry_bldr= new StringBuilder();
				newentry_bldr.append(splitstring[0]);
				newentry_bldr.append(onetoMany);
				newentry_bldr.append(splitstring[1]);
				System.out.println("newentry_bldr.toString()"+newentry_bldr.toString());
				collection_arr_association.add(newentry_bldr.toString());
			}
	}

		System.out.println("final_List_association"+ association);
		System.out.println("interim_List_collection_arr_association"+ collection_arr_association);
	
		
		for(int i=0;i<collection_arr_association.size();i++ ){
			
			collection_arr_association.set(i,collection_arr_association.get(i).replace(word_zerotomany, zerotomany));
		}
		
		System.out.println("final_collection_arr_association");
		
		System.out.println(collection_arr_association);
	}
	private static void createDiagram(List<FileInfo> listFileInfo, String path) {

		ByteArrayOutputStream bous = new ByteArrayOutputStream();

		final String interfaceConstant = " <|.. ";
		final String classExtdConstant = " <|-- ";
		final String usesConstant = " ..> ";

		StringBuilder sbr = new StringBuilder();
		sbr.append("\n");
		sbr.append("@startuml\n");
		/*
		 * source +="class Apartment{\n"; source +="rooms: int[]\n"; source
		 * +="}\n"; source +="class House\n"; source +="Apartment <|-- House\n";
		 * source +="class Commune\n";
		 */
		String filename = "";
		for (FileInfo fileInfo : listFileInfo) {
			filename = fileInfo.filename;
			
			if (fileInfo.isFIleAnInterface)
				sbr.append("interface ");
				
				else 
					sbr.append("class ");
			
			sbr.append(filename);
			sbr.append("{\n");

			for (String s : fileInfo.attributes) {

				sbr.append(s);
				sbr.append("\n");

			}
			for (String s : fileInfo.mtdsDcrld) {

				sbr.append(s);
				sbr.append("\n");

			}
			
			for (String s : fileInfo.constructorsDclrd) {

				sbr.append(s);
				sbr.append("\n");

			}
			
			sbr.append("}\n");
			// interface implts Class11 <|.. Class12 here Class11 is interface
			// impltd by Class12
			for (String interfaceimplt : fileInfo.interfaceImpltd) {
				sbr.append(interfaceimplt);
				sbr.append(interfaceConstant);
				sbr.append(filename);
				sbr.append("\n");
			}

			// extends Class01 <|-- Class02 here Class01 is parent , Class02 is
			// child
			for (String classextd : fileInfo.classesExtnd) {
				sbr.append(classextd);
				sbr.append(classExtdConstant);
				sbr.append(filename);
				sbr.append("\n");
			}

			// uses list Class15 ..> Class16 arrow from 15 to 16
			for (String uses : fileInfo.interface_classesUsed_Mtds) {
				sbr.append(filename);
				sbr.append(usesConstant);
				sbr.append(uses);
				sbr.append("\n");
			}

		}
		// add association n collarr appending here
		
		for (String uses : finalset_association) {
			sbr.append(uses);
			sbr.append("\n");
		}
		
		for (String uses : finalset_collection_arr_association) {
			sbr.append(uses);
			sbr.append("\n");
		}
		
		sbr.append("@enduml\n");

		System.out.println("final_mehnat"+sbr.toString());
		SourceStringReader reader = new SourceStringReader(sbr.toString());
		// Write the first image to "png"
		String desc = "";
		try {
			desc = reader.generateImage(bous);

			// Return a null string if no generation
			byte[] data = bous.toByteArray();

			InputStream in = new ByteArrayInputStream(data);
			BufferedImage convImg = ImageIO.read(in);
			ImageIO.write(convImg, "png", new File(path));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void populateConstructors(ConstructorDeclaration n, FileInfo fileInfo) {
		System.out.println(" populateConstructors");
		System.out.println("n.getName()" + n.getName());
		System.out.println("n.getTypeParameters()" + n.getTypeParameters());
		System.out.println("n.getModifiers()" + n.getModifiers());
		System.out.println("n.getParameters()" + n.getParameters());
		// System.out.println("n.getBody()"+n.getBody());
		System.out.println("n.getThrows()" + n.getThrows());
		// populate only public mtds
		if (n.getModifiers() == 1) {
			StringBuilder sbldr = new StringBuilder();

			/*sbldr.append("+ ");
			sbldr.append(n.getName());
			sbldr.append(n.getParameters().toString().replace('[', '(').replace(']', ')'));
			String temp = sbldr.toString();
			System.out.println(temp);
			fileInfo.constructorsDclrd.add(temp);*/
			
			
			List<Parameter> plist = n.getParameters();
			System.out.println("plist" + plist);
			StringBuilder sbr = new StringBuilder();

			boolean moreParams = false;

			for (Parameter p : plist) {

				if (moreParams) {
					sbr.append(",");
				}
				moreParams = true;

				/*
				 * System.out.println("pgetType___" + p.getType());
				 * System.out.println("p.getType()Class" + p.getType().getClass());
				 * System.out.println("p_getId_getName__"+p.getId().getName());
				 */

				sbr.append(p.getId().getName());
				sbr.append(":");
				sbr.append(p.getType());

			}

			StringBuilder sbrmtd = new StringBuilder();

			if (n.getModifiers() == 1 || n.getModifiers() == 9) {
				sbrmtd.append("+ ");
				System.out.println("getName______" + n.getName());
				sbrmtd.append(n.getName());
				sbrmtd.append("(");
				sbrmtd.append(sbr);
				sbrmtd.append(")");
				fileInfo.constructorsDclrd.add(sbrmtd.toString());
			}
			// This logic is for dependency
			if (n.getParameters().size()>0)
			populateUsesFor_MtdDecln(n.getParameters(), fileInfo);
			if (n.getBlock()!=null)
			populateUsesFor_MtdBody(n.getBlock(), fileInfo);
			
		}
	}

	void populateMtdSignature(MethodDeclaration n, FileInfo fileInfo) {
		System.out.println("n.getName()" + n.getName());
		System.out.println("n.getTypeParameters()" + n.getTypeParameters());
		System.out.println("n.getModifiers()" + n.getModifiers());
		System.out.println("n.getParameters()" + n.getParameters());
		System.out.println("n.getArrayCount()" + n.getArrayCount());
		System.out.println("n.getBody()" + n.getBody());
		BlockStmt blockStmt = n.getBody();

		System.out.println("n.getThrows()" + n.getThrows());
		System.out.println("n.getType()" + n.getType());

		String str = n.getDeclarationAsString(true, false);
		System.out.println("n.getDeclarationAsString(true, false): " + str);

		/*
		 * int space = str.indexOf(" "); String before = str.substring(0,
		 * space); String after = str.substring(space + 1);
		 * if(before.equals("public")){ System.out.println(
		 * "populateMtdSignature if entered"); System.out.println("+ "+ after );
		 * fileInfo.mtdsDcrld.add("+ "+ after);
		 * 
		 * }
		 * 
		 * 
		 * if (n.getModifiers() == 1) { StringBuilder sbldr = new
		 * StringBuilder();
		 * 
		 * sbldr.append("+ "); sbldr.append(n.getName());
		 * sbldr.append(n.getParameters().toString().replace('[',
		 * '(').replace(']', ')')); sbldr.append(":");
		 * sbldr.append(n.getType()); String temp = sbldr.toString();
		 * System.out.println(temp); fileInfo.mtdsDcrld.add(temp); }
		 */

		List<Parameter> plist = n.getParameters();
		System.out.println("plist" + plist);
		StringBuilder sbr = new StringBuilder();

		boolean moreParams = false;

		for (Parameter p : plist) {

			if (moreParams) {
				sbr.append(",");
			}
			moreParams = true;

			/*
			 * System.out.println("pgetType___" + p.getType());
			 * System.out.println("p.getType()Class" + p.getType().getClass());
			 * System.out.println("p_getId_getName__"+p.getId().getName());
			 */

			sbr.append(p.getId().getName());
			sbr.append(":");
			sbr.append(p.getType());

		}

		StringBuilder sbrmtd = new StringBuilder();

		if (n.getModifiers() == 1 || n.getModifiers() == 9) {
			sbrmtd.append("+ ");
			System.out.println("getName______" + n.getName());
			sbrmtd.append(n.getName());
			sbrmtd.append("(");
			sbrmtd.append(sbr);
			sbrmtd.append(")");
			sbrmtd.append(" : ");
			sbrmtd.append(n.getType());
			fileInfo.mtdsDcrld.add(sbrmtd.toString());
		}

		/*System.out.println((n.getParameters()).get(0).getType());
		System.out.println((n.getParameters()).get(0).getType().getData());
		System.out.println(n.getModifiers());
*/
		//
		// below is for dependency in mtd declrn
		if (n.getParameters().size()>0)
		populateUsesFor_MtdDecln(n.getParameters(), fileInfo);
		if (n.getBody()!=null)
		populateUsesFor_MtdBody(n.getBody(), fileInfo);
		//
	}

	private void populateUsesFor_MtdBody(BlockStmt body, FileInfo fileInfo) {
		// TODO Auto-generated method stub
		for (Node nblock : body.getChildrenNodes()) {
			System.out.println("nblock" + nblock.getClass());
			if (nblock instanceof ExpressionStmt) {
				ExpressionStmt exprStmt = (ExpressionStmt) nblock;
				List<Node> nodeExpr = exprStmt.getChildrenNodes();
				if (nodeExpr.size() > 0 && nodeExpr.get(0) instanceof VariableDeclarationExpr) {
					System.out.println("nodeExpr.get(0).getClass()" + nodeExpr.get(0).getClass());
					System.out.println("nodeExpr.get(0)" + nodeExpr.get(0));
					// if
					VariableDeclarationExpr vd = (VariableDeclarationExpr) nodeExpr.get(0);
					System.out.println("nblock_vdgetType" + vd.getType());
					if (vd.getType().getChildrenNodes().size() > 0) {
						System.out.println("vdgetTypeChilds__" + vd.getType().getChildrenNodes().get(0).getClass());
						ClassOrInterfaceType cit = (ClassOrInterfaceType) vd.getType().getChildrenNodes().get(0);
						System.out.println("cit" + cit.getTypeArgs());

						fileInfo.interface_classesUsed_Mtds
								.add(cit.getTypeArgs() != null ? cit.getTypeArgs().get(0).toString() : cit.toString());
					}
				}

			}
		}
	}

	void populateUsesFor_MtdDecln(List<Parameter> plist, FileInfo fileInfo) {
		// List<Parameter> plist = n.getParameters();
		System.out.println("plist" + plist);
		for (Parameter p : plist) {
			System.out.println("p.getType()" + p.getType());
			System.out.println("p.getType()Class" + p.getType().getClass());
			// for array p.getType().getChildrenNodes().get(0) will yiled the
			// refdatatype while for collection we need to dig futher
			if (p.getType() instanceof ReferenceType) {
				System.out.println("p.getType().getChildrenNodes()" + p.getType().getChildrenNodes());
				System.out.println("p.getType().getChildrenNodes().get(0)" + p.getType().getChildrenNodes().get(0));
				if (p.getType().getChildrenNodes().get(0).getChildrenNodes().size() == 0)
					fileInfo.interface_classesUsed_Mtds.add(p.getType().getChildrenNodes().get(0).toString());
				else {
					System.out.println("p.getType().getChildrenNodes().get(0).getChildrenNodes().get(0).toString()"
							+ p.getType().getChildrenNodes().get(0).getChildrenNodes().get(0).toString());
					fileInfo.interface_classesUsed_Mtds
							.add(p.getType().getChildrenNodes().get(0).getChildrenNodes().get(0).toString());
				}

			}
			if (p.getType() instanceof ClassOrInterfaceType) {

				System.out.println("p.getType().getChildrenNodes().get(0)" + p.getType().getChildrenNodes().get(0));
				fileInfo.interface_classesUsed_Mtds.add(p.getType().getChildrenNodes().get(0).toString());
			}
		}
	}

	// void
	void populateAttributes(FieldDeclaration fd, FileInfo fileInfo) {
		int modifier = fd.getModifiers();
		 System.out.println(fd + "fd.getModifiers() "+ fd.getModifiers() );
		if ((modifier == 1) || (modifier == 2)) {
			
			String modifier_notation= modifier == 1? "+ ":"- ";
			
			System.out.println("populateAttributes if entered");
			
			VariableDeclarator vd = (VariableDeclarator) (fd.getVariables()).get(0);
			String vdid_str=vd.getId().toString();
			System.out.println(vdid_str);

			List<Node> node = fd.getChildrenNodes();
			// assocn code
			// ref Class09 -- Class10
			// class01 has many ref's of 2 Class01 "1" *-- "many" Class02 :
			// contains
			System.out.println("fd.getTypegetClass"+fd.getType().getClass());
			if (fd.getType() instanceof ReferenceType) {
				// assocation may be der
				String classassocnmul = null;
				System.out.println("node" + node);
				System.out.println("node.get(0).getClass()" + node.get(0).getClass());
				System.out.println("node.get(1).getClass()" + node.get(1).getClass());
				ReferenceType rfinside = (ReferenceType) node.get(0);

				System.out.println("rfinside: " + rfinside);

				String str = fd.getType().toString();
				StringBuilder sbr = new StringBuilder();
				
				if (str.contains("[")) {
					classassocnmul = node.get(0).getChildrenNodes().get(0).toString();
					System.out.println("classassocnmul" + classassocnmul);
					//this means class is not custom class 
					if (!classes_interfaceParsed.contains(classassocnmul)){
						fileInfo.attributes.add(modifier_notation+ vdid_str + ":" + fd.getType());
					}
					else
					populateAssocnCol(classassocnmul, fileInfo);
				}

				else if (str.contains("<")) {
					classassocnmul = node.get(0).getChildrenNodes().get(0).getChildrenNodes().get(0).toString();
					if (!classes_interfaceParsed.contains(classassocnmul)){
						fileInfo.attributes.add(modifier_notation + vdid_str + ":" + fd.getType());
					}
					else{
					populateAssocnCol(classassocnmul, fileInfo);
					System.out.println("[2__" + classassocnmul);
					}

				} else {
					classassocnmul=str;
					//if populates the java objects else populates custom classes   
					if (!classes_interfaceParsed.contains(classassocnmul)){
						fileInfo.attributes.add(modifier_notation+vdid_str + ":" + fd.getType());
					}
					else
					{
						System.out.println("entered here");
					populateAssocn(rfinside.toString(), fileInfo);
					}
				}

			}
			if (fd.getType() instanceof PrimitiveType) {
				System.out.println("Primitve in " + fileInfo.filename);
				System.out.println(vdid_str + ":" + fd.getType());
				
				fileInfo.attributes.add(modifier_notation +vdid_str + ":" + fd.getType());

			}
		}
	}

	private void populateAssocnCol(String classassocnmul, FileInfo fileInfo) {
		String filename = fileInfo.filename;
		StringBuilder sbr = new StringBuilder();

		// Class01 "1" *-- "many" Class02 : contains

		sbr.append(filename);
		sbr.append(word_zerotomany);
		sbr.append(classassocnmul);

		if (!collection_arr_association.contains(sbr.toString()))
		collection_arr_association.add(sbr.toString());
		System.out.println("[__word_zerotomany" + sbr.toString());

	}

	private void populateAssocn(String classassocnmul, FileInfo fileInfo) {
		String filename = fileInfo.filename;
		StringBuilder sbr = new StringBuilder();
		
			sbr.append(filename);
			sbr.append(zerotoone);
			sbr.append(classassocnmul);
			if (!association.contains(sbr.toString()))
		association.add(sbr.toString());
		System.out.println("[__zerotoone" + sbr.toString());
	}
	// Logic..Populate the lsit with the classes which r to be parsed
	// call all the methods to be parsed i n for loop 1 by 1 for each do below
	// attributes 4 lists interface impltd,used n classes impltd n used , 1 list
	// for mtd decln, 1 list of params, 1 list of uses
	// Step 1 determine its class/interface and make an entry in golbal list
	// Step 2 get the classes extnd n interfaces impltd
	// Get child A>if mtd declrn 1.populate signature 2. chk uses using
	// prepopulated list of file parsed
	// B> if field declrn 1. populate List of this class 2. Put association list
	// any references

	// Note only the consumers of mtd will have dependency/ will populate the
	// list , the declarator/creator of function will not populate dependency
	// list
	//
}
