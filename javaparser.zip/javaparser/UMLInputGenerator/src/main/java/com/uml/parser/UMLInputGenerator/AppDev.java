package com.uml.parser.UMLInputGenerator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseException;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

/**
 * Hello world!
 *
 */
public class AppDev {

	static List<String> classesParsed = new ArrayList<String>();
	static List<String> interfaceParsed = new ArrayList<String>();
	
	List<FileInfo> listFileInfo = new ArrayList<FileInfo>();
	FileInfo fileInfo = null;

	public List<FileInfo> getListFileInfo() {
		return listFileInfo;
	}

	public void setListFileInfo(List<FileInfo> listFileInfo) {
		this.listFileInfo = listFileInfo;
	}

	public FileInfo getFileInfo() {
		return fileInfo;
	}

	public void setFileInfo(FileInfo fileInfo) {
		this.fileInfo = fileInfo;
	}

	private void populateParsedFiles() {
		List<String> parsedList = new ArrayList<String>();
		final String JAVA_CONSTANT = "java";

		// FileInputStream in = null;
		// CompilationUnit cu = null;

		try {
			Files.walk(Paths.get("D:/SJSU/Paul_202/uml-parser-test-2/uml-parser-test-2")).forEach(filePath -> {
				if (Files.isRegularFile(filePath)) {
					System.out.println(filePath);
					File f1 = filePath.toFile();
					System.out.println(f1.getName());
					String[] splitted = f1.getName().split("\\.");
					System.out.println();

					if (splitted[1].equals(JAVA_CONSTANT)) {
						try {
							FileInputStream in = new FileInputStream(filePath.toString());
							CompilationUnit cu = JavaParser.parse(in);

							Object node = cu.getData();

							// System.out.println(node.);
							// Node pr = cu.getParentNode();
							// parentnode.
							System.out.println("CU B1 types" + cu.getTypes());

							// Type Declaration can be AnnotationDeclaration,
							// ClassOrInterfaceDeclaration,
							// EmptyTypeDeclaration, EnumDeclaration
							// VVVVVVIMP ClassOrInterfaceDeclaration has private
							// boolean interface_;
							ClassOrInterfaceDeclaration cx = (ClassOrInterfaceDeclaration) cu.getTypes().get(0);
							if (cx.isInterface()) {
								interfaceParsed.add(splitted[0]);
							} else
								classesParsed.add(splitted[0]);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						// parsedList.add(splitted[0]);
					}
				}
			});
			System.out.println(classesParsed);
			System.out.println(interfaceParsed);
			// System.out.println(parsedList.contains("Ax"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// System.out.println( "Hello World!" );

		FileInputStream in = null;
		CompilationUnit cu = null;
		List<ClassOrInterfaceType> extendList= null;
		List<ClassOrInterfaceType> interfaceList=null;
		
		
		AppDev app = new AppDev();
		app.populateParsedFiles();
		
		
		FileInfo fileInfotemp = null;
		//List<FileInfo> listFileInfo = new ArrayList<FileInfo>();
		ClassOrInterfaceDeclaration cx = null;
		final File folder = new File("D:/SJSU/Paul_202/uml-parser-test-2/uml-parser-test-2");
		
		for (final File fileEntry : folder.listFiles()) {
			cx=null;
			
			if (!fileEntry.isDirectory()) {

				fileInfotemp = new FileInfo();
				
				try {
					in = new FileInputStream(fileEntry);
					cu = JavaParser.parse(in);
					Object node = cu.getData();
					
					
					for (TypeDeclaration typeDeclaration:cu.getTypes() ){
						if (typeDeclaration instanceof ClassOrInterfaceDeclaration) {
							 cx = (ClassOrInterfaceDeclaration) typeDeclaration;
							break;
						} 
							
					}
					
					if (cx.isInterface())
						fileInfotemp.isFIleAnInterface = true;
					
					 extendList = cx.getExtends();
					
					for (ClassOrInterfaceType ciType: extendList){
						
						fileInfotemp.classesExtnd.add(ciType.toString());
						fileInfotemp.classesExtnd.retainAll(classesParsed);
					}
					
					interfaceList = cx.getImplements();
					
					for (ClassOrInterfaceType ciType: interfaceList){
						
						fileInfotemp.interfaceImpltd.add(ciType.toString());
						fileInfotemp.interfaceImpltd.retainAll(interfaceParsed);
					}
					
					//set the temp var in class var so that it can be accessed in class
					app.setFileInfo(fileInfotemp);
					System.out.println("==============BELOW IS VISITING METHODS==========");
					new MethodVisitor().visit(cu, null);
					System.out.println("Trying to get Types");
					//List<TypeDeclaration> lst	=cu.getTypes();
					//System.out.println(lst.size());
					//System.out.println(lst.get(0).getName());
					//processNode(cu.get);
					/*cu.getChildrenNodes();
					List<VariableDeclarator> lstvars= 	new FieldDeclaration().getVariables();
					System.out.println(lstvars);*/
					
					new FieldVisitor().visit(cu,null);
					
					
					//extendList.retainAll(classesParsed);
					//fileInfo.classesExtnd=extendList;
					
					app.getListFileInfo().add(fileInfotemp) ;
					
					// System.out.println(cx.getExtends());
					// System.out.println(cx.getExtends().get(0));

				} catch (FileNotFoundException | ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}

		/*
		 * 
		 * try { in = new FileInputStream(
		 * "D:/SJSU/Paul_202/JavaParser/DevTest/src/CollectionFunc.java"); cu =
		 * JavaParser.parse(in); Object node = cu.getData();
		 * 
		 * // System.out.println(node.); //Node pr = cu.getParentNode();
		 * //parentnode. System.out.println("CU B1 types"+cu.getTypes());
		 * 
		 * //Type Declaration can be AnnotationDeclaration,
		 * ClassOrInterfaceDeclaration, EmptyTypeDeclaration, EnumDeclaration
		 * //VVVVVVIMP ClassOrInterfaceDeclaration has private boolean
		 * interface_; ClassOrInterfaceDeclaration cx=
		 * (ClassOrInterfaceDeclaration) cu.getTypes().get(0);
		 * //MethodDeclaration mx= (MethodDeclaration) cx.get;
		 * System.out.println(cx.getExtends());
		 * //System.out.println(cx.getExtends().get(0));
		 * System.out.println(cx.getImplements());
		 * //System.out.println(cx.getImplements().get(0)); System.out.println(
		 * "Parent node form child:"+ cx.getParentNode());
		 * 
		 * System.out.println("Cu children nodes");
		 * System.out.println(cu.getChildrenNodes());
		 * System.out.println("Size"+cu.getChildrenNodes().size());
		 * System.out.println("cu.children "
		 * +cu.getChildrenNodes().get(0).getChildrenNodes());
		 * 
		 * System.out.println("Size"+cx.getChildrenNodes().size());
		 * System.out.println("cx.getclass"+cx.getChildrenNodes().get(0).
		 * getClass());
		 * System.out.println("cx.getclass"+cx.getChildrenNodes().get(1).
		 * getClass());
		 * System.out.println("cx.getclass"+cx.getChildrenNodes().get(2).
		 * getClass());
		 * System.out.println("cx.getclass"+cx.getChildrenNodes().get(3).
		 * getClass());
		 * System.out.println("cx.getclass"+cx.getChildrenNodes().get(4).
		 * getClass()); ClassOrInterfaceType clt=(ClassOrInterfaceType)
		 * cx.getChildrenNodes().get(0);
		 * //System.out.println("cx.getclass"+cx.getChildrenNodes().get(5).
		 * getClass());
		 * //System.out.println("cx.getclass"+cx.getChildrenNodes().get(6).
		 * getClass()); Node parentnode = cu.getParentNode();
		 * System.out.println("Cu parent  nodes");
		 * System.out.println(parentnode);
		 * 
		 * } catch (FileNotFoundException | ParseException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 * 
		 * finally { try { in.close(); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } }
		 * 
		 * //Below is to retrieve mtds and attributes
		 * 
		 * // prints the resulting compilation unit to default system output
		 * System.out.println("below is cu.toString()");
		 * System.out.println(cu.toString());
		 * 
		 * System.out.println(
		 * "==============BELOW IS VISITING METHODS=========="); new
		 * MethodVisitor().visit(cu, null); System.out.println(
		 * "Trying to get Types"); //List<TypeDeclaration> lst =cu.getTypes();
		 * //System.out.println(lst.size());
		 * //System.out.println(lst.get(0).getName()); //processNode(cu.get);
		 * cu.getChildrenNodes(); List<VariableDeclarator> lstvars= new
		 * FieldDeclaration().getVariables(); System.out.println(lstvars);
		 * 
		 * new FieldVisitor().visit(cu,null);
		 */
	}

	/**
	 * Simple visitor implementation for visiting MethodDeclaration nodes.
	 */
	private static class MethodVisitor extends VoidVisitorAdapter {

		@Override
		public void visit(MethodDeclaration n, Object arg) {
			// here you can access the attributes of the method.
			// this method will be called for all methods in this
			// CompilationUnit, including inner class methods
			
			
			///n.getTypeParameters() is null change it to void
			// check get modifiers for public type and add + in string
			// for functions signature add only of public
			
			
			System.out.println(n.getName());
			System.out.println(n.getTypeParameters());
			
			String str=n.getDeclarationAsString(true, false);
			System.out.println("n.getDeclarationAsString(true, false): "+str);
			
			int space = str.indexOf(" ");
			String before = str.substring(0, space);
			String after = str.substring(space + 1);
			if(before.equals("public")){
				System.out.println("+ "+ after );
				
				}
			

			System.out.println((n.getParameters()).get(0).getType());
			System.out.println((n.getParameters()).get(0).getType().getData());
			System.out.println(n.getModifiers());
		}

	}

	private static class FieldVisitor extends VoidVisitorAdapter {

		@Override
		public void visit(FieldDeclaration n, Object arg) {
			// here you can access the attributes of the method.
			// this method will be called for all methods in this
			// CompilationUnit, including inner class methods
			VariableDeclarator vd = (VariableDeclarator) (n.getVariables()).get(0);
			System.out.println(vd.getId());
			System.out.println(n.getType());
			System.out.println(n.getVariables());
			System.out.println(n.getModifiers());

			System.out.println("exiting field visitor");

		}
	}

	// Logic..Populate the lsit with the classes which r to be parsed
	// call all the methods to be parsed i n for loop 1 by 1 for each do below
	// attributes 4 lists interface impltd,used n classes impltd n used , 1 list
	// for mtd decln, 1 list of params, 1 list of uses
	// Step 1 determine its class/interface and make an entry in golbal list
	// Step 2 get the classes extnd n interfaces impltd
	// Get child A>if mtd declrn 1.populate signature 2. chk uses using
	// prepopulated list of file parsed
	// B> if field declrn 1. populate List of this class 2. Put association list
	// any references

	// Note only the consumers of mtd will have dependency/ will populate the
	// list , the declarator/creator of function will not populate dependency
	// list
	//
}
