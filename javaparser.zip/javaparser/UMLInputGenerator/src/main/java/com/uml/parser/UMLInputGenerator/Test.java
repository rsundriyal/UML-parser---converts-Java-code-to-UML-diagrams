package com.uml.parser.UMLInputGenerator;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseException;
import com.github.javaparser.ast.CompilationUnit;

public class Test {

	public static void main(String[] args) {
		FileInputStream in = null;
		CompilationUnit cu = null;
		try {
			in = new FileInputStream("D:/SJSU/Paul_202/uml-parser-test-2/uml-parser-test-2/A1.java");
			cu = JavaParser.parse(in);
			System.out.println(cu.toString());
		} catch (FileNotFoundException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
